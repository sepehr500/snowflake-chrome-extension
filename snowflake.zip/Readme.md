# Snowflake Chrome Extension

An extension to make the web less toxic
